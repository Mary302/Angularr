const connection = require("./connection-wrapper");
const ErrorType = require("../errors/error-type");
let ServerError = require("./../errors/server-error");


async function checkOut( userData,  order) {
    let sql = "INSERT INTO orders (userId, cartId, totalPrice, orderCity, OrderStreet, shippingDate, lastFourDigits) values(?,?,(SELECT SUM(totalPice) FROM cart_product c WHERE c.cartId = ?),?,?,?,?)"
    let params = [userData.Id, userData.cartId, userData.cartId, order.city, 
                  order.address, order.shippingdate, order.creditcard];
                  console.log("order doa params ======="+ JSON.stringify(order))
    try{
        await connection.executeWithParameters(sql, params);
        setCheckOut(userData)
        console.log(" order Dao All good ! ")

    } catch (error){ 

        console.log( " dao " + error)
        throw new ServerError(ErrorType.GENERAL_ERROR, sql, error);
    }

}



async function setCheckOut(userData){
    let today = new Date()
    let sql = " UPDATE shopping_cart SET isCheckedOut = ?, checkOutDate = ? WHERE shoppin_cartId = ? "
    let params = [1, today ,userData.cartId ]
    try{
        console.log("we are in order dao setCheckOut")
        console.log(params)

        await connection.executeWithParameters(sql, params);
        return;
   
       } catch (error){ 
   
        console.log( " dao setCheck " + error)
        throw new ServerError(ErrorType.GENERAL_ERROR, sql, error);
   
       }

}

async function getOrder(userId) {
    let sql = "SELECT * FROM orders JOIN cart_product on cart_product.userId = orders.userId JOIN shopping_cart on orders.userId = shopping_cart.userId WHERE orders.cartId = ?  ORDER BY creationDate DESC LIMIT 1";
    let params = [userId.cartId]
    console.log("order doa get order" + params)

    try{
    let myOrderComplitation;
    myOrderComplitation = await connection.executeWithParameters(sql, params);
    console.log("result order dao:" + JSON.stringify(myOrderComplitation));
    console.log("All good ! ")
    return myOrderComplitation;
    
    } catch (error) {

        console.log( "get order dao " + error)
        throw new ServerError(ErrorType.GENERAL_ERROR, sql, error);

    }
}

async function getUnavailableOrderDates() {
  conosle.log("WE MADE IT TO DAO")
    let sql =
      "SELECT COUNT(*) AS 'number_of_orders', DATE_FORMAT(ship_date, '%Y-%m-%d') AS 'ship_date'from orders where shippingDate > current_timestamp() GROUP BY shippingDate HAVING number_of_orders >= 3";
  
    try {
      let unavailable_dates;
      unavailable_dates = await connection.execute(sql);
     console.log(JSON.stringify(unavailable_dates))
      return unavailable_dates;
    } catch (error) {
      throw new ServerError(ErrorType.GENERAL_ERROR, sql, error);
    }
  }


module.exports = {checkOut,
    setCheckOut,
    getOrder,
    getUnavailableOrderDates
    }
