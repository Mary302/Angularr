const cartItemsLogic = require("../logic/cartItems-logic")
const express = require("express");
let usersCache = require("../dao/cache-module");


const router = express.Router();

router.post("/", async (request, response, next) => {

    let authorizationString = request.headers["authorization"];
    let token = authorizationString.substring("Bearer ".length);
    let userData = usersCache.get(token);
    console.log(userData)
    let product = request.body;
    console.log( "carItems req" + JSON.stringify(request.body))
    console.log("item controller user:" +  JSON.stringify(userData), "product" +  JSON.stringify(product.product), "amount" + product.units);


    try {
        await cartItemsLogic.addItemToCart(userData ,product);
        response.json();
    }
    catch (err) {
        // return next(error);
        console.error(err);
        response.status(600).send(err.message);
    }
});


router.get("/myCart", async (request, response, next) => {

    let authorizationString = request.headers["authorization"];
    let token = authorizationString.substring("Bearer ".length);
    let userData = usersCache.get(token);
    console.log(userData)
  
    try {
        let myOrder = await cartItemsLogic.getCartItems( userData);
        console.log("============" + JSON.stringify(userData) + "===========")
        console.log("cart i c controller" + JSON.stringify(myOrder))
        response.json (myOrder)
      } catch (err) {
        // return next(error);
        console.log("Failed to get cart items");
        console.error(err);
        response.status(600).send(err.message);
    
      }
  
  }); 

  // router.delete("/", async (request, response, next) => {
  //   try {
  //     let authorizationString = request.headers["authorization"];
  
  //     // Removing the bearer prefix, leaving the clean token
  //     let token = authorizationString.substring("Bearer ".length);
  //     let userData = cacheModule.get(token);
  
  //     await cartItemsLogic.deleteAllCartItems(userData.cart_id);
  //     response.json();
  //   } catch (error) {
  //     return next(error);
  //   }
  // });
  
  router.delete("/:id", async (request, response, next) => {
    try {
      let productId = request.params.id;
      console.log("++++++++==========="+request.params.id);
      let authorizationString = request.headers["authorization"];
  
      let token = authorizationString.substring("Bearer ".length);
      let userData = usersCache.get(token);
  
      let updatedItems = await cartItemsLogic.deleteCartItem(userData, productId);
      response.json(updatedItems);
    } catch (error) {
      return next(error);
    }
  });

  router.delete("/",async (request, response) =>{
    let authorizationString = request.headers["authorization"];
    let token = authorizationString.substring("Bearer ".length);
    let userData = usersCache.get(token);
    try{
      let cartToDelete = await cartItemsLogic.deleteCartByCartId(userData,token)
      response.json(cartToDelete)
    }
    catch (err) {
      console.log("Failed to get carts");
      console.error(err);
      response.status(600).send(err.message);
    }
  })

  router.get("/myPrice", async (request, response, next) => {

    let authorizationString = request.headers["authorization"];
    let token = authorizationString.substring("Bearer ".length);
    let userData = usersCache.get(token);
    console.log(userData)
  
    try {
        let myPrice = await cartItemsLogic.getTotalPrice( userData);
        console.log("============" + JSON.stringify(userData) + "===========")
        console.log("cart myPrice controller" + JSON.stringify(myPrice))
        response.json (myPrice)
      } catch (err) {
        // return next(error);
        console.log("Failed to get cart items");
        console.error(err);
        response.status(600).send(err.message);
    
      }
  
  }); 
    module.exports = router;