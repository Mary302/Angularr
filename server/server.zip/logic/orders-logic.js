const ordersDao = require("../dao/orders-dao");
const shoppingcartDao = require("../dao/shopping_cart-dao")
const ServerError = require("../errors/server-error")
const ErrorType = require("../errors/error-type");


async function checkOut( userData, order) {
  console.log("order logic check out"+ JSON.stringify(userData), "order" + JSON.stringify(order))
    await ordersDao.checkOut( userData, order )
    return;
    
  }
  

  async function getOrder(userId) {
    let getOrder = await ordersDao.getOrder(userId);
    console.log( " order logic getOrder" +JSON.stringify(getOrder))
    if(!getOrder){
    return}
    console.log(JSON.stringify(getOrder))
 
    return getOrder;
  }

  async function getUnavailableOrderDates() {
    try {
      let unavailable_dates = await ordersDao.getUnavailableOrderDates();
  
      return unavailable_dates;
    } catch (error) {
      throw new ServerError(ErrorType.GENERAL_ERROR, "order-logic !", error);
    }
  }

  module.exports = {
    checkOut,
    getOrder,
    getUnavailableOrderDates
  };
  