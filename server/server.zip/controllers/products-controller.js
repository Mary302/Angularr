const express = require("express");
const usersCache = require("../dao/cache-module");
const productsLogic = require("../logic/products-logic");
const router = express.Router();
const server = express();


server.use(express.static('client'));

router.put("/uploads", async (req,res)=>{
  try{
    let authorizationString = req.headers["authorization"];
    let token = authorizationString.substring("Bearer ".length);
    let userData = usersCache.get(token);
    const file = req.files.file;
    let product = req.body
    console.log(JSON.stringify(product))
    if(req.files===null){
      let succesfulUpdateResponse = await productsLogic.updateProduct(product, userData)
      res.json(succesfulUpdateResponse);
 
     }else{
       console.log(req.files)
       const file = req.files.file;
       let successfulUploadResponse = await productsLogic.uploadProductImage(
         file,product,userData
       );
         console.log("PHOTO NAME "+successfulUploadResponse)
         res.json(successfulUploadResponse);
     }
  }
  catch(err){
      console.log(err)
  res.status(500).json 
  }
})

router.post("/addProduct", async (req,res)=>{
  try{
    let authorizationString = req.headers["authorization"];
    let token = authorizationString.substring("Bearer ".length);
    let userData = usersCache.get(token);
    let product = req.body
    
      console.log("WE MADE IT TO ADD")
      const file = req.files.file;
      console.log("PRODUCT!!!!:"+JSON.stringify(product))

      let successfulUploadResponse = await productsLogic.addNewProduct(
        file,product,userData
      );
        console.log("PHOTO NAME "+successfulUploadResponse)
        res.json(successfulUploadResponse);
    }
  
  catch(err){
      console.log(err)
  res.status(500).json 
  }
})




router.get("/", async (request, response) => {
 
  try {
  // In order to succeed, we must extract the user's id from the cache
  let authorizationString = request.headers["authorization"];

  // Removing the bearer prefix, leaving the clean token
  let token = authorizationString.substring("Bearer ".length);
  let userData = usersCache.get(token);


    let ProductsList = await productsLogic.getAllProducts();
    response.json(ProductsList);
  } catch (err) {
    // return next(error);
    console.log("Failed to get products");
    console.error(err);
    response.status(600).send(error.message);

  }
});

router.post("/newProduct", async (request, response, next) => {

  // Extracting the JSON from the packet's BODY
  let product = request.body;
  console.log(JSON.stringify(product))

  try {
      await productsLogic.addNewProduct(product);
      console.log("products add new controller")
      response.json();
  }
  catch (err) {
      console.error(err);
      response.status(600).send(err.message);
  }
});

router.put("/updateProduct", async (request, response, next) => {
  


  // Extracting the JSON from the packet's BODY
  let product = request.body;
  console.log(" CONTROLLER"+JSON.stringify(product))

  try {
      await productsLogic.updateProduct(product);
      console.log("products update controller")
      response.json();
  }
  catch (err) {
      console.error(err);
      response.status(600).send(err.message);
  }
});



module.exports = router;
