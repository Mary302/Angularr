const shoppingCartLogic = require("../logic/shopping_cart-logic")
const express = require("express");
let usersCache = require("../dao/cache-module");
const router = express.Router();



router.get("/", async (request, response, next) => {

  
    try {  
    let authorizationString = request.headers["authorization"];
    let token = authorizationString.substring("Bearer ".length);
    let userData = usersCache.get(token);
    console.log("shopping control"+ JSON.stringify(userData))

        let shoppingCart = await shoppingCartLogic.getRecentCartByUserId(userData, token);
        response.json(shoppingCart);
        console.log("shopping cart control" + shoppingCart + "userData" + JSON.stringify(userData) )
      } catch (err) {
        // return next(error);
        console.log("Failed to get shopping cart");
        console.error(err);
        response.status(600).send(err.message);
    
      }
});

module.exports = router;
