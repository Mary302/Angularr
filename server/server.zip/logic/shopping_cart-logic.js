const shoppingCartDao = require('../dao/shopping_cart-dao')
let usersCache = require("../dao/cache-module");


// async function getMyCart(userID){
//   return await shoppingCartDao.getMyCart(userID);

// }
async function isShoppingCartExisting(user){
  let cartExists;
  cartExists = await shoppingCartDao.isShoppingCartExisting(user);
  if(cartExists.length !== []){
    console.log("cart already exist" + JSON.stringify(cartExists))
    return true;
} 

   console.log("inside if where []" + "user" + JSON.stringify(user))
    await shoppingCartDao.createShoppingCart(user);
    // let newCart = await shoppingCartDao.getRecentCartByUserId(user);
    return false;
   

}


async function getRecentCartByUserId( userData, token) {
  console.log("SHOPPIN LOGIC 27"+JSON.stringify(userData))

    let recent_cart = await shoppingCartDao.getRecentCartByUserId(userData);
    if (recent_cart != undefined && recent_cart.length != 0) {
      console.log(JSON.stringify(recent_cart))
      userData.cartId = recent_cart.shoppin_cartId;
      usersCache.set(token,userData);
      console.log("SHOPPIN LOGIC 35"+JSON.stringify(recent_cart))
      return recent_cart.shoppin_cartId;
    }
    if (recent_cart === undefined || recent_cart.length == 0){
       let newCart =await createShoppingCart(userData);
       console.log("shoping caty logic 38" + JSON.stringify(recent_cart))
       return newCart.insertId;

    }
  
    
  }

  async function createShoppingCart (user){
    let newCart = await shoppingCartDao.createShoppingCart(user);
    // await shoppingCartDao.getRecentCartByUserId(user, token)
    return newCart;

}

  async function deleteCartByUserId (userId){
      await shoppingCartDao.deleteCartByUserId(userId);

  }
module.exports = {
    getRecentCartByUserId,
    deleteCartByUserId,
    isShoppingCartExisting,
    createShoppingCart}